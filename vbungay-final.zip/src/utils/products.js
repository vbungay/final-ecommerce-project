import Item from '../assets/Item.png';

export const homeItem = [
    { id: 1, name: 'Air Jordan 4', description: 'Bred', price: '250', imgSrc: Item}
]